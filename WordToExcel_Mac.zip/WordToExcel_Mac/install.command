#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "============================================"
echo "  WordToExcel - установка (macOS)"
echo "============================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ОШИБКА] Python 3 не найден."
    echo "Установите его с https://www.python.org/downloads/macos/"
    echo "(версия с сайта python.org уже содержит tkinter)"
    echo
    read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
    echo
    exit 1
fi

python3 --version

if ! python3 -c "import tkinter" >/dev/null 2>&1; then
    echo
    echo "[ВНИМАНИЕ] tkinter не найден."
    echo "Если Python установлен через Homebrew, выполните:"
    echo "    brew install python-tk"
    echo "Либо поставьте Python с https://www.python.org/downloads/macos/"
    echo
fi

echo "Создаю виртуальное окружение venv..."
python3 -m venv venv || {
    echo "[ОШИБКА] Не удалось создать venv."
    read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
    exit 1
}

echo "Устанавливаю библиотеки python-docx и openpyxl..."
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt || {
    echo "[ОШИБКА] Не удалось установить зависимости."
    read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
    exit 1
}

echo
echo "============================================"
echo "  ГОТОВО! Запускайте программу: run.command"
echo "============================================"
read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
echo
