#!/bin/bash
cd "$(dirname "$0")" || exit 1

if [ -x "./venv/bin/python" ]; then
    exec ./venv/bin/python app.py
fi

if command -v python3 >/dev/null 2>&1; then
    exec python3 app.py
fi

echo "[ОШИБКА] Python 3 не найден. Сначала выполните install.command"
read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
