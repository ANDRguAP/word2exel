#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "Сборка WordToExcel.app (может занять 1-2 минуты)..."

if [ -x "./venv/bin/python" ]; then
    PY=./venv/bin/python
else
    PY=python3
fi

$PY -m pip install --upgrade pyinstaller || {
    echo "[ОШИБКА] Не удалось установить PyInstaller."
    read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
    exit 1
}

$PY -m PyInstaller --noconfirm --windowed --name WordToExcel app.py || {
    echo "[ОШИБКА] Сборка не удалась."
    read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
    exit 1
}

echo
echo "============================================"
echo "  ГОТОВО: dist/WordToExcel.app"
echo "  Можно перетащить в папку Applications."
echo "============================================"
read -n 1 -s -r -p "Нажмите любую клавишу для выхода..."
echo
