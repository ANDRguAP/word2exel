@echo off
chcp 65001 >nul
cd /d "%~dp0"
title WordToExcel - сборка EXE

set "PY=python"
where py >nul 2>nul
if %errorlevel%==0 set "PY=py"

echo Устанавливаю PyInstaller...
%PY% -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo [ОШИБКА] Не удалось установить PyInstaller.
    pause
    exit /b 1
)

echo Собираю WordToExcel.exe (это займёт 1-2 минуты)...
%PY% -m PyInstaller --noconfirm --onefile --windowed --name WordToExcel app.py
if errorlevel 1 (
    echo [ОШИБКА] Сборка не удалась.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   ГОТОВО: dist\WordToExcel.exe
echo   Этот файл работает без установленного Python.
echo ============================================
pause
