@echo off
chcp 65001 >nul
cd /d "%~dp0"
title WordToExcel

where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw "%~dp0app.py"
    exit /b
)
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "%~dp0app.py"
    exit /b
)

echo Запускаю через python (окно консоли можно свернуть)...
python "%~dp0app.py"
if errorlevel 1 (
    echo.
    echo [ОШИБКА] Запуск не удался. Сначала выполните install.bat
    pause
)
