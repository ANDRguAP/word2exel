@echo off
chcp 65001 >nul
cd /d "%~dp0"
title WordToExcel - установка

echo ============================================
echo   WordToExcel - установка зависимостей
echo ============================================
echo.

set "PY=python"
where py >nul 2>nul
if %errorlevel%==0 set "PY=py"

%PY% --version >nul 2>nul
if errorlevel 1 (
    echo [ОШИБКА] Python не найден.
    echo.
    echo Установите Python 3.8+ с https://www.python.org/downloads/windows/
    echo При установке ОБЯЗАТЕЛЬНО отметьте:
    echo    [x] Add python.exe to PATH
    echo    [x] tcl/tk and IDLE  (нужно для окна программы)
    echo.
    pause
    exit /b 1
)

echo Использую интерпретатор: %PY%
%PY% --version
echo.

%PY% -c "import tkinter" >nul 2>nul
if errorlevel 1 (
    echo [ВНИМАНИЕ] tkinter не найден. Переустановите Python с галочкой "tcl/tk and IDLE".
    echo.
)

echo Устанавливаю библиотеки python-docx и openpyxl...
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ОШИБКА] Не удалось установить зависимости.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   ГОТОВО! Запускайте программу: run.bat
echo ============================================
pause
